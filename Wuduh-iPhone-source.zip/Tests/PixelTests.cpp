#include "../Wuduh/PixelCore.h"
#include <vector>
#include <iostream>
#include <cmath>
#include <cstdlib>
int main(){const int w=128,h=96,step=12,gw=(w+step-1)/step+1,gh=(h+step-1)/step+1;std::vector<unsigned char>a(w*h*4),b(w*h*4);unsigned int seed=1;for(int y=0;y<h;y++)for(int x=0;x<w;x++){seed=seed*1664525+1013904223;for(int c=0;c<3;c++)a[(y*w+x)*4+c]=(unsigned char)(seed>>24);a[(y*w+x)*4+3]=255;}for(int y=0;y<h;y++)for(int x=0;x<w;x++)for(int c=0;c<4;c++)b[(y*w+x)*4+c]=x>=8?a[(y*w+x-8)*4+c]:0;std::vector<float>ab(gw*gh*4),ba(gw*gh*4);float cut=WDComputeFlow(a.data(),b.data(),w,h,w*4,w*4,step,24,ab.data(),ba.data());float dx=0,dy=0;int n=0;for(int gy=2;gy<gh-2;gy++)for(int gx=2;gx<gw-2;gx++){dx+=ab[(gy*gw+gx)*4];dy+=ab[(gy*gw+gx)*4+1];n++;}dx/=n;dy/=n;if(std::abs(dx-8)>0.25||std::abs(dy)>0.25||cut!=0)return 1;std::vector<float>tile(3*192*192);WDFillTile(a.data(),w,h,w*4,0,0,192,40,tile.data());if(std::abs(tile[40*192+40]-a[2]/255.f)>.00001)return 2;std::cout<<"motion dx="<<dx<<" dy="<<dy<<" sceneCut="<<cut<<"; reflected RGB tensor OK\n";return 0;}

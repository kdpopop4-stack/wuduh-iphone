import XCTest
import Metal
import CoreVideo
@testable import Wuduh

final class PipelineTests:XCTestCase {
    func pattern(width:Int=128,height:Int=96,shift:Int=0) throws -> CVPixelBuffer {
        let out=try pixelBuffer(width,height);CVPixelBufferLockBaseAddress(out,[]);defer{CVPixelBufferUnlockBaseAddress(out,[])}
        let p=CVPixelBufferGetBaseAddress(out)!.assumingMemoryBound(to:UInt8.self),row=CVPixelBufferGetBytesPerRow(out)
        for y in 0..<height {for x in 0..<width {let px=max(0,x-shift),v=UInt8(truncatingIfNeeded:((px*1103515245+y*12345)^((px+7)*(y+11)*97))>>8);for c in 0..<3 {p[y*row+x*4+c]=v};p[y*row+x*4+3]=255}}
        return out
    }
    func testMotionAndNovelMiddleFrame() throws {
        guard MTLCreateSystemDefaultDevice() != nil else{throw XCTSkip("Metal unavailable on this simulator host; run on physical iPhone.")}
        let renderer=try MotionRenderer(),a=try pattern(),b=try pattern(shift:8),pair=try MotionPair(a:a,b:b,device:renderer.device)
        let grid=pair.ab.contents().assumingMemoryBound(to:SIMD4<Float>.self);XCTAssertEqual(grid[4*pair.gridWidth+5].x,8,accuracy:1)
        let middle=try renderer.render(a:a,b:b,pair:pair,alpha:0.5)
        func channel(_ image:CVPixelBuffer,_ x:Int,_ y:Int)->Int{CVPixelBufferLockBaseAddress(image,.readOnly);defer{CVPixelBufferUnlockBaseAddress(image,.readOnly)};return Int(CVPixelBufferGetBaseAddress(image)!.assumingMemoryBound(to:UInt8.self)[y*CVPixelBufferGetBytesPerRow(image)+x*4])}
        XCTAssertEqual(Double(channel(middle,64,48)),Double(channel(a,60,48)),accuracy:2.0)
        XCTAssertNotEqual(channel(middle,64,48),channel(a,64,48))
        XCTAssertNotEqual(channel(middle,64,48),channel(b,64,48))
    }
    func testBundledAIHasRealPrediction() throws {
        let enhancer=try AIEnhancer(),source=try pattern(width:16,height:16)
        let out=try enhancer.enhance(source,strength:1,control:RunControl())
        XCTAssertEqual(CVPixelBufferGetWidth(out),64);XCTAssertEqual(CVPixelBufferGetHeight(out),64)
    }
    func testWriterAndFrameCount() async throws {
        guard MTLCreateSystemDefaultDevice() != nil else{throw XCTSkip("Metal unavailable on host.")}
        let url=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString+".mp4")
        defer{try? FileManager.default.removeItem(at:url)}
        let writer=try SegmentWriter(url:url,size:CGSize(width:320,height:180),fps:60),buffer=try pattern(width:320,height:180),control=RunControl()
        for i in 0..<6 {try await writer.append(buffer,index:i,fps:60,control:control)}
        try await writer.finish(frames:6,fps:60)
        let engine=try VideoEngine(),valid=try await engine.verify(url,width:320,height:180,frames:6,fps:60)
        XCTAssertTrue(valid)
    }
    func testCancelFlagIsCheckedBetweenTiles() {let control=RunControl();control.pause();XCTAssertThrowsError(try control.check())}
}

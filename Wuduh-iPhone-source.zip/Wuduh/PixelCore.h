#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
// Grid points are (gx*step, gy*step), clamped to the image. XY are pixel displacements.
float WDComputeFlow(const uint8_t* a,const uint8_t* b,int width,int height,int strideA,int strideB,int step,int radius,float* ab,float* ba);
void WDFillTile(const uint8_t* bgra,int width,int height,int row,int x,int y,int tile,int halo,float* chw);
void WDWriteTile(const float* chw,int tile,int halo,int x,int y,int coreWidth,int coreHeight,const uint8_t* original,int width,int height,int originalRow,uint8_t* dest,int destRow,float strength);
#ifdef __cplusplus
}
#endif

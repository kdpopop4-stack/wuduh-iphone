import Foundation
import AVFoundation
import CoreImage
import Photos
import UIKit
import Combine

@MainActor final class AppModel: ObservableObject {
    @Published var options=EnhanceOptions(){didSet{if let d=try? JSONEncoder().encode(options){UserDefaults.standard.set(d,forKey:"enhance-options")};updatePreview()}}
    @Published var source:URL?
    @Published var sourceName="لم يُختَر فيديو"
    @Published var player:AVPlayer?
    @Published var progress:Double=0
    @Published var message="المعالجة محلية؛ اختر فيديو من الصور أو الملفات."
    @Published var running=false
    @Published var importing=false
    @Published var jobs=[VideoJob]()
    @Published var result:URL?
    @Published var showOriginal=false{didSet{updatePreview()}}
    private var control:RunControl?
    private var observers=[NSObjectProtocol]()
    private var previewItem:AVPlayerItem?
    private var previewTask:Task<Void,Never>?
    private let previewContext=CIContext(options:[.cacheIntermediates:false])
    init(){
        if let data=UserDefaults.standard.data(forKey:"enhance-options"),let saved=try? JSONDecoder().decode(EnhanceOptions.self,from:data){options=saved}
        reload()
        for name in [UIApplication.didEnterBackgroundNotification,UIApplication.didReceiveMemoryWarningNotification,ProcessInfo.thermalStateDidChangeNotification] {
            observers.append(NotificationCenter.default.addObserver(forName:name,object:nil,queue:.main){[weak self] notification in
                Task{@MainActor in
                    guard let self else{return}
                    if notification.name != ProcessInfo.thermalStateDidChangeNotification || ProcessInfo.processInfo.thermalState == .serious || ProcessInfo.processInfo.thermalState == .critical {self.control?.pause()}
                }
            })
        }
    }
    func reload(){jobs=JobStore.history()}
    func imported(_ url:URL,name:String){source=url;sourceName=name;result=nil;let item=AVPlayerItem(url:url);previewItem=item;player=AVPlayer(playerItem:item);updatePreview();message="جاهز. جرّب 3 ثوانٍ أولًا؛ المعاينة المباشرة للألوان دون AI."}
    func importURL(_ url:URL){guard !running else{return};importing=true;message="نسخ الفيديو المختار إلى مساحة التطبيق…";Task{do{let copy=try await Task.detached(priority:.userInitiated){try JobStore.importVideo(url)}.value;imported(copy,name:url.lastPathComponent)}catch{message=error.localizedDescription};importing=false}}
    func updatePreview(){
        previewTask?.cancel()
        previewTask=Task{
            do{try await Task.sleep(nanoseconds:80_000_000)}catch{return}
            guard !Task.isCancelled else{return}
            applyPreview()
        }
    }
    private func applyPreview(){
        guard let source,let item=previewItem,!running else{return}
        if result != nil {result=nil;player=AVPlayer(playerItem:item)}
        if showOriginal{item.videoComposition=nil;return}
        let o=options,context=previewContext
        let composition=AVMutableVideoComposition(asset:AVURLAsset(url:source),applyingCIFiltersWithHandler:{ request in
            let filtered=ImagePipeline.adjustments(request.sourceImage.clampedToExtent(),options:o).cropped(to:request.sourceImage.extent)
            request.finish(with:filtered,context:context)
        })
        composition.colorPrimaries=AVVideoColorPrimaries_ITU_R_709_2;composition.colorTransferFunction=AVVideoTransferFunction_ITU_R_709_2;composition.colorYCbCrMatrix=AVVideoYCbCrMatrix_ITU_R_709_2;item.videoComposition=composition
    }
    func professional(){options.ai=true;options.aiStrength=0.45;options.shadows=0.3;options.highlights=0.2;options.exposure=0;options.contrast=1;options.saturation=1;options.warmth=0;options.autoWhite=true}
    func start(sample:Bool){guard let source,!running else{return};let job=VideoJob(source:source.path,name:sourceName,options:options,sample:sample);execute(job)}
    func resume(_ job:VideoJob){guard !running,job.status != "مكتملة" else{return};source=URL(fileURLWithPath:job.source);sourceName=job.name;options=job.options;execute(job)}
    func pause(){control?.pause();message="حفظ التقدم وإيقاف الجزء الجاري…"}
    private func execute(_ job:VideoJob){
        guard ProcessInfo.processInfo.thermalState != .serious,ProcessInfo.processInfo.thermalState != .critical else{message="الجهاز ساخن؛ اتركه يبرد ثم استكمل.";return}
        player?.pause();running=true;result=nil;progress=0;UIApplication.shared.isIdleTimerDisabled=true
        let token=RunControl();control=token
        Task{
            do {
                let completed=try await Task.detached(priority:.userInitiated){
                    let engine=try VideoEngine()
                    return try await engine.run(job,control:token){[weak self] value,fraction,stage in
                        Task{@MainActor in self?.progress=fraction;self?.message=stage}
                    }
                }.value
                if let output=completed.output{result=URL(fileURLWithPath:output);player=AVPlayer(url:result!)}
                message="اكتمل: \(completed.width) × \(completed.height) / \(completed.options.fps) إطارًا."
            } catch {
                message=error.localizedDescription
                if var latest=JobStore.history().first(where:{$0.id==job.id}){latest.status="متوقفة";latest.detail=message;try? JobStore.save(latest)}
            }
            running=false;control=nil;UIApplication.shared.isIdleTimerDisabled=false;reload()
        }
    }
    func open(_ job:VideoJob){guard let path=job.output else{return};source=URL(fileURLWithPath:job.source);sourceName=job.name;previewItem=AVPlayerItem(url:source!);options=job.options;result=URL(fileURLWithPath:path);player=AVPlayer(url:result!)}
    func saveToPhotos(){guard let result else{return};PHPhotoLibrary.requestAuthorization(for:.addOnly){[weak self] status in
        guard status == .authorized || status == .limited else{Task{@MainActor in self?.message="لم يُمنح إذن إضافة الفيديو إلى الصور. يمكنك حفظه من زر المشاركة."};return}
        PHPhotoLibrary.shared().performChanges({PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL:result)}){success,error in Task{@MainActor in self?.message=success ? "حُفظ الفيديو في الصور.":(error?.localizedDescription ?? "تعذر الحفظ في الصور.")}}
    }}
}

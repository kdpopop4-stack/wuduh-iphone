import SwiftUI
import PhotosUI
import AVKit
import UniformTypeIdentifiers

struct MoviePicker:UIViewControllerRepresentable {
    var started:()->Void
    var done:(URL,String)->Void
    var failed:(String)->Void
    @Environment(\.dismiss) private var dismiss
    func makeUIViewController(context:Context)->PHPickerViewController {var c=PHPickerConfiguration(photoLibrary:.shared());c.filter = .videos;c.selectionLimit=1;let picker=PHPickerViewController(configuration:c);picker.delegate=context.coordinator;return picker}
    func updateUIViewController(_ uiViewController:PHPickerViewController,context:Context){}
    func makeCoordinator()->Coordinator{Coordinator(self)}
    final class Coordinator:NSObject,PHPickerViewControllerDelegate {
        let parent:MoviePicker;init(_ parent:MoviePicker){self.parent=parent}
        func picker(_ picker:PHPickerViewController,didFinishPicking results:[PHPickerResult]){
            parent.dismiss();guard let result=results.first else{return};parent.started();let parent=self.parent,name=result.itemProvider.suggestedName ?? "فيديو من الصور"
            result.itemProvider.loadFileRepresentation(forTypeIdentifier:UTType.movie.identifier){url,error in
                guard let url else{DispatchQueue.main.async{parent.failed(error?.localizedDescription ?? "تعذر تحميل الفيديو المختار.")};return}
                do {let copy=try JobStore.importVideo(url);DispatchQueue.main.async{parent.done(copy,name)}}catch{DispatchQueue.main.async{parent.failed(error.localizedDescription)}}
            }
        }
    }
}
@MainActor struct ContentView:View {
    @StateObject private var model=AppModel()
    @State private var photoPicker=false
    @State private var filePicker=false
    @State private var previewEditor=false
    private let lime=Color(red:0.84,green:0.96,blue:0.54)
    var body:some View {
        NavigationStack {
            Form {
                Section {
                    Text("AI محلي مجاني • دون رفع الفيديو").font(.headline).foregroundStyle(lime)
                    Text("تحسين التفاصيل مقدّر وقد يغيّر النسيج. 4K و60 إطارًا خيارات تصدير؛ سرعة المعالجة تعتمد على الجهاز.").font(.footnote).foregroundStyle(.secondary)
                }
                Section("الفيديو") {
                    HStack{Button("من الصور"){photoPicker=true};Spacer();Button("من الملفات"){filePicker=true}}.disabled(model.running || model.importing)
                    Text(model.sourceName).lineLimit(2).font(.footnote)
                    if let player=model.player {VideoPlayer(player:player).frame(height:220);Button("فتح نافذة الفيديو وضبط الإضاءة"){previewEditor=true}.disabled(model.running || model.result != nil);Toggle("إظهار الأصل دون تعديل المعاينة",isOn:$model.showOriginal).disabled(model.running || model.result != nil);Text("المعاينة المباشرة للألوان فقط؛ جرّب 3 ثوانٍ لرؤية AI وتوليد الإطارات.").font(.caption).foregroundStyle(.secondary)}
                }
                Section("الإخراج") {
                    Picker("الدقة",selection:$model.options.edge){Text("4K — حتى 3840 × 2160").tag(2160);Text("1080p — أخف للجهاز").tag(1080)}
                    Picker("الإطارات",selection:$model.options.fps){Text("60 إطارًا / ثانية").tag(60);Text("30 إطارًا / ثانية").tag(30)}
                    Text("توليد إطارات بحركة مقدّرة، مع الاحتفاظ بإطار مصدر عند قطع المشهد أو حدود الفيديو. الإخراج SDR مع الصوت.").font(.caption).foregroundStyle(.secondary)
                }.disabled(model.running)
                Section("تفاصيل AI") {
                    Toggle("Real-ESRGAN مجاني على الهاتف",isOn:$model.options.ai)
                    control("قوة AI",value:$model.options.aiStrength,range:0...1)
                    Picker("دقة معالجة AI",selection:$model.options.aiLongEdge){Text("960 بكسل — ذاكرة ووقت أقل").tag(960);Text("1920 بكسل — أبطأ وذاكرة أكثر").tag(1920)}
                    Text("يُعاد تحجيم المصدر عند تجاوز دقة AI المختارة. النموذج يكبّر ×4 ثم يضبط على الإخراج؛ قد تفقد إعادة التحجيم بعض تفاصيل مصدر 4K.").font(.caption).foregroundStyle(.secondary)
                    Button("مظهر احترافي معتدل + AI"){model.professional()}
                }.disabled(model.running)
                Section("ضوء وألوان — معاينة مباشرة") {
                    Toggle("توازن أبيض تقديري ثابت",isOn:$model.options.autoWhite)
                    control("الإضاءة EV",value:$model.options.exposure,range:-1...1)
                    control("التباين",value:$model.options.contrast,range:0.8...1.3)
                    control("تشبع الألوان",value:$model.options.saturation,range:0...1.5)
                    control("رفع الظلال",value:$model.options.shadows,range:0...1)
                    control("تخفيف اللمعان",value:$model.options.highlights,range:0...1)
                    control("الدفء",value:$model.options.warmth,range:-30...30)
                }.disabled(model.running)
                Section {
                    if model.running {ProgressView(value:model.progress);Button("إيقاف وحفظ التقدم",role:.cancel){model.pause()}}
                    else {Button("تجربة أول 3 ثوانٍ"){model.start(sample:true)}.disabled(model.source == nil || model.importing);Button("معالجة الفيديو كاملًا"){model.start(sample:false)}.disabled(model.source == nil || model.importing)}
                    Text(model.message).font(.footnote)
                    Text("المتاح الآن: \(Double(JobStore.free())/1_073_741_824,specifier:"%.1f") GB. يُحفظ التقدم عند الحرارة العالية أو الانتقال للخلفية؛ استكمل من السجل.").font(.caption).foregroundStyle(.secondary)
                    if let result=model.result {HStack{ShareLink("مشاركة / حفظ في الملفات",item:result);Spacer();Button("حفظ في الصور"){model.saveToPhotos()}}}
                }
                Section("المهام المحفوظة") {
                    if model.jobs.isEmpty{Text("لا توجد مهام بعد.").foregroundStyle(.secondary)}
                    ForEach(model.jobs){job in VStack(alignment:.leading,spacing:6){Text(job.name).lineLimit(1);Text("\(job.status) • \(job.completed)/\(job.total) أجزاء").font(.caption).foregroundStyle(.secondary);if job.output != nil {Button("فتح النتيجة"){model.open(job)}.disabled(model.running)}else{Button("استكمال بالإعدادات المحفوظة"){model.resume(job)}.disabled(model.running)}}}
                }
                Section {Text("التطبيق لا ينسخ التطبيقات أو المحادثات أو جهات الاتصال احتياطيًا، ولا يصل إليها. يحفظ الفيديو الذي تختاره ونتائج المعالجة فقط. يبقى الأصل في الصور أو الملفات.").font(.caption).foregroundStyle(.secondary)}
            }.navigationTitle("وضوح — iPhone").tint(lime)
        }.preferredColorScheme(.dark).environment(\.layoutDirection,.rightToLeft)
        .sheet(isPresented:$previewEditor){PreviewEditor(model:model)}
        .sheet(isPresented:$photoPicker){MoviePicker(started:{model.importing=true;model.message="تحميل الفيديو المختار ونسخه محليًا…"},done:{url,name in model.importing=false;model.imported(url,name:name)},failed:{model.importing=false;model.message=$0})}
        .fileImporter(isPresented:$filePicker,allowedContentTypes:[.movie],allowsMultipleSelection:false){result in switch result {case .success(let urls):if let url=urls.first{model.importURL(url)};case .failure(let error):model.message=error.localizedDescription}}
    }
    private func control(_ name:String,value:Binding<Float>,range:ClosedRange<Float>)->some View {VStack(alignment:.leading){HStack{Text(name);Spacer();Text(String(format:"%.2f",value.wrappedValue)).monospacedDigit().foregroundStyle(.secondary)};Slider(value:value,in:range)}}
}

@MainActor struct PreviewEditor:View {
    @ObservedObject var model:AppModel
    @Environment(\.dismiss) private var dismiss
    var body:some View {
        VStack(spacing:12){
            HStack{Text("معاينة الفيديو").font(.headline);Spacer();Button("تم"){dismiss()}}
            if let player=model.player {VideoPlayer(player:player).frame(height:240)}
            Toggle("عرض الأصل",isOn:$model.showOriginal)
            Text("تعديل ألوان مباشر؛ AI وتقدير الإطارات يظهران في تجربة 3 ثوانٍ.").font(.caption).foregroundStyle(.secondary)
            ScrollView{VStack(spacing:18){
                slider("الإضاءة EV",value:$model.options.exposure,range:-1...1)
                slider("التباين",value:$model.options.contrast,range:0.8...1.3)
                slider("تشبع الألوان",value:$model.options.saturation,range:0...1.5)
                slider("رفع الظلال",value:$model.options.shadows,range:0...1)
                slider("تخفيف اللمعان",value:$model.options.highlights,range:0...1)
                slider("الدفء",value:$model.options.warmth,range:-30...30)
            }.padding(.vertical)}
        }.padding().preferredColorScheme(.dark).environment(\.layoutDirection,.rightToLeft)
    }
    private func slider(_ text:String,value:Binding<Float>,range:ClosedRange<Float>)->some View{VStack{HStack{Text(text);Spacer();Text(String(format:"%.2f",value.wrappedValue)).monospacedDigit()};Slider(value:value,in:range)}}
}

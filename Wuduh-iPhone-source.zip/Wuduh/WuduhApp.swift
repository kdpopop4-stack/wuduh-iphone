import SwiftUI
@main struct WuduhApp:App {var body:some Scene{WindowGroup{ContentView()}}}

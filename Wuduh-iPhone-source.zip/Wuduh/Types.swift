import Foundation
import AVFoundation
import CoreVideo
import UIKit

struct EnhanceOptions: Codable, Equatable {
    var edge = 2160
    var fps = 60
    var ai = true
    var aiStrength: Float = 0.45
    var aiLongEdge = 960
    var exposure: Float = 0
    var contrast: Float = 1
    var saturation: Float = 1
    var shadows: Float = 0.3
    var highlights: Float = 0.2
    var warmth: Float = 0
    var autoWhite = true
}
struct VideoJob: Codable, Identifiable {
    var id = UUID()
    var source: String
    var name: String
    var options: EnhanceOptions
    var sample: Bool
    var created = Date()
    var status = "جاهزة"
    var completed = 0
    var total = 0
    var frameCount = 0
    var duration: Double = 0
    var width = 0
    var height = 0
    var white: [Float] = [1,1,1]
    var whiteAnalyzed = false
    var output: String?
    var sourceBytes: Int64 = 0
    var sourceStamp: Double = 0
    var pipelineVersion = "ios-0.1.0"
    var detail: String?
}
struct ExportReport: Codable {
    var width: Int; var height: Int; var fps: Int; var frames: Int; var seconds: Double
    var audio: Bool; var model: String; var aiStrength: Float; var aiLongEdge: Int
    var interpolation = "Bidirectional block motion, occlusion consistency and Metal warping; source/nearest frame at scene cuts and boundaries"
    var color = "SDR / Rec.709 / 8-bit; source HDR tone-mapped by AVFoundation"
    var estimatedDetails = true
}
enum WuduhError: LocalizedError {
    case message(String), paused
    var errorDescription: String? { switch self {case .message(let s): return s; case .paused: return "توقفت المعالجة؛ الأجزاء المكتملة محفوظة. يمكنك الاستكمال."} }
}
final class RunControl: @unchecked Sendable {
    private let lock = NSLock()
    private var stopped = false
    func pause() { lock.lock(); stopped = true; lock.unlock() }
    func check() throws {
        lock.lock(); let stop = stopped; lock.unlock()
        if stop || ProcessInfo.processInfo.thermalState == .serious || ProcessInfo.processInfo.thermalState == .critical { throw WuduhError.paused }
    }
}
enum JobStore {
    static var root: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] }
    static var jobs: URL { root.appendingPathComponent("Jobs", isDirectory: true) }
    static func folder(_ id: UUID) -> URL { jobs.appendingPathComponent(id.uuidString, isDirectory: true) }
    static func save(_ job: VideoJob) throws {
        let dir = folder(job.id); try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        try JSONEncoder().encode(job).write(to: dir.appendingPathComponent("job.json"), options: .atomic)
    }
    static func history() -> [VideoJob] {
        let dirs = (try? FileManager.default.contentsOfDirectory(at: jobs, includingPropertiesForKeys: nil)) ?? []
        return dirs.compactMap { try? JSONDecoder().decode(VideoJob.self, from: Data(contentsOf: $0.appendingPathComponent("job.json"))) }.sorted { $0.created > $1.created }
    }
    static func free() -> Int64 { (try? root.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]).volumeAvailableCapacityForImportantUsage) ?? 0 }
    static func importVideo(_ url: URL) throws -> URL {
        let access = url.startAccessingSecurityScopedResource(); defer { if access {url.stopAccessingSecurityScopedResource()} }
        let bytes = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        guard free() > Int64(bytes) + 512 * 1024 * 1024 else { throw WuduhError.message("لا تكفي المساحة لنسخ الفيديو محليًا. اختر ملفًا أصغر أو حرّر مساحة.") }
        let dir = root.appendingPathComponent("Imports", isDirectory: true);try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let ext = url.pathExtension.isEmpty ? "mov" : url.pathExtension
        let target = dir.appendingPathComponent(UUID().uuidString+"."+ext)
        try FileManager.default.copyItem(at: url, to: target); return target
    }
}
func pixelBuffer(_ width: Int, _ height: Int) throws -> CVPixelBuffer {
    var buffer: CVPixelBuffer?
    let status = CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
        [kCVPixelBufferIOSurfacePropertiesKey as String: [:], kCVPixelBufferMetalCompatibilityKey as String: true] as CFDictionary, &buffer)
    guard status == kCVReturnSuccess, let buffer else { throw WuduhError.message("تعذر تخصيص ذاكرة إطار الفيديو.") }; return buffer
}
func fitSize(_ size: CGSize, edge: Int) -> CGSize {
    let landscape = size.width >= size.height
    let maxW = CGFloat(landscape ? edge*16/9 : edge), maxH = CGFloat(landscape ? edge : edge*16/9)
    let scale = min(maxW/size.width,maxH/size.height)
    return CGSize(width: CGFloat(max(2,Int(size.width*scale)/2*2)), height: CGFloat(max(2,Int(size.height*scale)/2*2)))
}
let rec709: [String: Any] = [AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_709_2, AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2, AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2]

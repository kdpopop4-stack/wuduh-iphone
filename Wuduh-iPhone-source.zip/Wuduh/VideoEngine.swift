import Foundation
import AVFoundation
import CoreVideo
import VideoToolbox

final class SourceFrame {
    let buffer: CVPixelBuffer
    let time: Double
    var enhanced: CVPixelBuffer?
    var reference: CVPixelBuffer?
    init(_ buffer:CVPixelBuffer,_ time:Double){self.buffer=buffer;self.time=time}
    func output(ai:AIEnhancer?,options:EnhanceOptions,control:RunControl) throws -> CVPixelBuffer {
        if let enhanced{return enhanced};let value=try ai?.enhance(buffer,strength:options.aiStrength,control:control) ?? buffer;enhanced=value;return value
    }
}
final class FrameReader {
    private let reader:AVAssetReader
    private let output:AVAssetReaderVideoCompositionOutput
    init(asset:AVAsset,track:AVAssetTrack,duration:CMTime,sourceSize:CGSize,transform:CGAffineTransform,workSize:CGSize,start:Double,end:Double,nominal:Float) throws {
        reader=try AVAssetReader(asset:asset)
        let composition=AVMutableVideoComposition();composition.renderSize=workSize
        composition.frameDuration=CMTime(seconds:1/Double(nominal>0 && nominal.isFinite ? min(nominal,120):30),preferredTimescale:60000)
        composition.colorPrimaries=AVVideoColorPrimaries_ITU_R_709_2;composition.colorTransferFunction=AVVideoTransferFunction_ITU_R_709_2;composition.colorYCbCrMatrix=AVVideoYCbCrMatrix_ITU_R_709_2
        let bounds=CGRect(origin:.zero,size:sourceSize).applying(transform)
        let normalized=transform.concatenating(CGAffineTransform(translationX:-bounds.minX,y:-bounds.minY)).concatenating(CGAffineTransform(scaleX:workSize.width/bounds.width,y:workSize.height/bounds.height))
        let layer=AVMutableVideoCompositionLayerInstruction(assetTrack:track);layer.setTransform(normalized,at:.zero)
        let instruction=AVMutableVideoCompositionInstruction();instruction.timeRange=CMTimeRange(start:.zero,duration:duration);instruction.layerInstructions=[layer];composition.instructions=[instruction]
        output=AVAssetReaderVideoCompositionOutput(videoTracks:[track],videoSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA,AVVideoColorPropertiesKey:rec709,AVVideoAllowWideColorKey:false]);output.videoComposition=composition;output.alwaysCopiesSampleData=false
        guard reader.canAdd(output) else {throw WuduhError.message("صيغة الفيديو غير مدعومة في قارئ iOS.")};reader.add(output)
        reader.timeRange=CMTimeRange(start:CMTime(seconds:start,preferredTimescale:60000),end:CMTime(seconds:end,preferredTimescale:60000))
        guard reader.startReading() else {throw reader.error ?? WuduhError.message("تعذر فتح الفيديو.")}
    }
    func next() throws -> SourceFrame? {
        if let sample=output.copyNextSampleBuffer(),let buffer=CMSampleBufferGetImageBuffer(sample){return SourceFrame(buffer,CMSampleBufferGetPresentationTimeStamp(sample).seconds)}
        if reader.status == .failed {throw reader.error ?? WuduhError.message("فشلت قراءة إطار المصدر.")};return nil
    }
    deinit{if reader.status == .reading{reader.cancelReading()}}
}
final class SegmentWriter {
    private let writer:AVAssetWriter
    private let input:AVAssetWriterInput
    private let adaptor:AVAssetWriterInputPixelBufferAdaptor
    init(url:URL,size:CGSize,fps:Int) throws {
        writer=try AVAssetWriter(outputURL:url,fileType:.mp4)
        let bitrate=(size.width*size.height>3_000_000 ? 28_000_000:10_000_000)*(fps==60 ? 1.3:1)
        var settings:[String:Any]=[AVVideoCodecKey:AVVideoCodecType.hevc,AVVideoWidthKey:Int(size.width),AVVideoHeightKey:Int(size.height),AVVideoColorPropertiesKey:rec709,AVVideoCompressionPropertiesKey:[AVVideoAverageBitRateKey:Int(bitrate),AVVideoExpectedSourceFrameRateKey:fps,AVVideoMaxKeyFrameIntervalKey:fps*2,AVVideoAllowFrameReorderingKey:false]]
        #if targetEnvironment(simulator)
        settings[AVVideoCodecKey]=AVVideoCodecType.h264
        #endif
        if !writer.canApply(outputSettings:settings,forMediaType:.video){settings[AVVideoCodecKey]=AVVideoCodecType.h264}
        guard writer.canApply(outputSettings:settings,forMediaType:.video) else {throw WuduhError.message("الدقة أو معدل الإطارات المطلوب غير مدعوم من مرمّز الجهاز. جرّب 1080p / 30.")}
        input=AVAssetWriterInput(mediaType:.video,outputSettings:settings);input.expectsMediaDataInRealTime=false;input.mediaTimeScale=60000
        adaptor=AVAssetWriterInputPixelBufferAdaptor(assetWriterInput:input,sourcePixelBufferAttributes:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA,kCVPixelBufferWidthKey as String:Int(size.width),kCVPixelBufferHeightKey as String:Int(size.height),kCVPixelBufferIOSurfacePropertiesKey as String:[:]])
        guard writer.canAdd(input) else {throw WuduhError.message("تعذر إنشاء مسار الإخراج.")};writer.add(input)
        guard writer.startWriting() else {throw writer.error ?? WuduhError.message("تعذر بدء التصدير.")};writer.startSession(atSourceTime:.zero)
    }
    func append(_ buffer:CVPixelBuffer,index:Int,fps:Int,control:RunControl) async throws {
        let deadline=Date().addingTimeInterval(30)
        while !input.isReadyForMoreMediaData {try control.check();if Date()>deadline {writer.cancelWriting();throw WuduhError.message("انتهت مهلة استجابة مرمّز الفيديو. جرّب دقة أقل.")};if writer.status != .writing{throw writer.error ?? WuduhError.message("توقف المرمّز.")};try await Task.sleep(nanoseconds:5_000_000)}
        guard adaptor.append(buffer,withPresentationTime:CMTime(value:Int64(index),timescale:Int32(fps))) else {throw writer.error ?? WuduhError.message("تعذر كتابة إطار الفيديو.")}
    }
    func finish(frames:Int,fps:Int) async throws {
        writer.endSession(atSourceTime:CMTime(value:Int64(frames),timescale:Int32(fps)));input.markAsFinished()
        await withCheckedContinuation{(c:CheckedContinuation<Void,Never>) in writer.finishWriting{c.resume()}}
        if writer.status != .completed{throw writer.error ?? WuduhError.message("تعذر إكمال الجزء.")}
    }
    deinit{if writer.status == .writing{writer.cancelWriting()}}
}
final class VideoEngine {
    let motion:MotionRenderer
    let images:ImagePipeline
    init() throws {motion=try MotionRenderer();images=ImagePipeline(device:motion.device)}
    func verify(_ url:URL,width:Int,height:Int,frames:Int,fps:Int) async throws -> Bool {
        let asset=AVURLAsset(url:url);guard let track=try await asset.loadTracks(withMediaType:.video).first else{return false}
        let size=try await track.load(.naturalSize),duration=try await asset.load(.duration)
        guard Int(size.width)==width,Int(size.height)==height,abs(duration.seconds-Double(frames)/Double(fps))<0.08 else{return false}
        let reader=try AVAssetReader(asset:asset),output=AVAssetReaderTrackOutput(track:track,outputSettings:nil);reader.add(output);guard reader.startReading() else{return false}
        var count=0;while let sample=output.copyNextSampleBuffer(){count+=CMSampleBufferGetNumSamples(sample)}
        return count==frames && reader.status == .completed
    }
    func run(_ original:VideoJob,control:RunControl,progress:@escaping @Sendable (VideoJob,Double,String)->Void) async throws -> VideoJob {
        var job=original;guard job.pipelineVersion == "ios-0.1.0",[1080,2160].contains(job.options.edge),[30,60].contains(job.options.fps),[960,1920].contains(job.options.aiLongEdge),(0...1).contains(job.options.aiStrength) else {throw WuduhError.message("إعدادات المهمة أو إصدارها غير مدعوم. أنشئ مهمة جديدة.")};let dir=JobStore.folder(job.id);try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        let source=URL(fileURLWithPath:job.source),asset=AVURLAsset(url:source)
        let fingerprint=try source.resourceValues(forKeys:[.fileSizeKey,.contentModificationDateKey]);let length=Int64(fingerprint.fileSize ?? 0),stamp=fingerprint.contentModificationDate?.timeIntervalSince1970 ?? 0
        if job.sourceBytes != 0 && (job.sourceBytes != length || job.sourceStamp != stamp){throw WuduhError.message("تغيّر المصدر؛ أنشئ مهمة جديدة لتجنب خلط أجزاء مختلفة.")}
        job.sourceBytes=length;job.sourceStamp=stamp
        guard let track=try await asset.loadTracks(withMediaType:.video).first else{throw WuduhError.message("لا يوجد مسار فيديو مدعوم.")}
        let sourceSize=try await track.load(.naturalSize),transform=try await track.load(.preferredTransform),nominal=try await track.load(.nominalFrameRate),assetDuration=try await asset.load(.duration)
        guard assetDuration.seconds.isFinite,assetDuration.seconds>0 else{throw WuduhError.message("مدة الفيديو غير صالحة.")}
        let display=CGRect(origin:.zero,size:sourceSize).applying(transform).size;let cleanSize=CGSize(width:abs(display.width),height:abs(display.height)),target=fitSize(cleanSize,edge:job.options.edge)
        let rate=job.options.fps,seconds=job.sample ? min(3,assetDuration.seconds):assetDuration.seconds,totalFrames=Int(ceil(seconds*Double(rate)-0.000001)),per=2*rate,total=(totalFrames+per-1)/per
        job.total=total;job.frameCount=totalFrames;job.duration=Double(totalFrames)/Double(rate);job.width=Int(target.width);job.height=Int(target.height)
        let ratio=job.options.ai ? min(1,CGFloat(job.options.aiLongEdge)/max(cleanSize.width,cleanSize.height)):1
        let work=CGSize(width:CGFloat(max(2,Int(cleanSize.width*ratio)/2*2)),height:CGFloat(max(2,Int(cleanSize.height*ratio)/2*2)))
        let existing=dir.appendingPathComponent("Wuduh-\(job.options.edge)p-\(job.options.fps)fps.mov")
        if FileManager.default.fileExists(atPath:existing.path),try await verify(existing,width:job.width,height:job.height,frames:totalFrames,fps:rate){return try await finalize(job,output:existing,source:asset,frames:totalFrames)}
        job.status="قيد المعالجة";try JobStore.save(job);progress(job,0,"تجهيز محرك AI المحلي…")
        let ai=job.options.ai ? try AIEnhancer():nil
        for segment in 0..<total {
            try control.check();let count=min(per,totalFrames-segment*per),start=Double(segment*per)/Double(rate),end=Double(segment*per+count)/Double(rate)
            let part=dir.appendingPathComponent(String(format:"part-%06d.mp4",segment)),partial=dir.appendingPathComponent(String(format:"part-%06d.working.mp4",segment))
            if FileManager.default.fileExists(atPath:part.path),try await verify(part,width:job.width,height:job.height,frames:count,fps:rate){job.completed=segment+1;try JobStore.save(job);progress(job,Double(segment+1)/Double(total),"استكمال جزء مكتمل");continue}
            guard JobStore.free()>512*1024*1024 else{throw WuduhError.message("المساحة المتاحة منخفضة؛ الأجزاء المكتملة محفوظة.")}
            try? FileManager.default.removeItem(at:partial)
            do {
                let padding=max(0.25,3/Double(max(1,nominal))),reader=try FrameReader(asset:asset,track:track,duration:assetDuration,sourceSize:sourceSize,transform:transform,workSize:work,start:max(0,start-padding),end:min(assetDuration.seconds,end+padding),nominal:nominal)
                guard var left=try reader.next() else{throw WuduhError.message("تعذر قراءة بداية الجزء.")};var right=try reader.next()
                if !job.whiteAnalyzed {job.white=job.options.autoWhite ? try images.estimateWhite(left.buffer):[1,1,1];job.whiteAnalyzed=true;try JobStore.save(job)}
                let writer=try SegmentWriter(url:partial,size:target,fps:rate)
                var pair:MotionPair?
                func prepared(_ frame:SourceFrame) throws -> CVPixelBuffer {
                    if let enhanced=frame.enhanced{return enhanced}
                    let adjusted=try images.working(frame.buffer,options:job.options,white:job.white)
                    frame.reference=try images.reference(adjusted)
                    let enhanced=try ai?.enhance(adjusted,strength:job.options.aiStrength,control:control) ?? adjusted;frame.enhanced=enhanced;return enhanced
                }
                for local in 0..<count {
                    try control.check();let time=Double(segment*per+local)/Double(rate)
                    while let next=right,next.time<=time+0.000001 {left=next;right=try reader.next();pair=nil}
                    let rendered:CVPixelBuffer = try autoreleasepool {
                        let a=try prepared(left)
                        if let next=right,next.time>left.time+0.000001,time>left.time+0.000001 {
                            let b=try prepared(next)
                            if pair==nil {pair=try MotionPair(a:left.reference!,b:next.reference!,device:motion.device)}
                            let alpha=Float(min(1,max(0,(time-left.time)/(next.time-left.time))))
                            return try images.scale(motion.render(a:a,b:b,pair:pair!,alpha:alpha),size:target,color709:true)
                        }
                        return try images.scale(a,size:target,color709:true)
                    }
                    try await writer.append(rendered,index:local,fps:rate,control:control)
                    progress(job,Double(segment*per+local+1)/Double(totalFrames),"الجزء \(segment+1)/\(total) — الإطار \(local+1)/\(count)\n\(ai?.backend ?? "تحسين تقليدي + Metal")")
                    await Task.yield()
                }
                try await writer.finish(frames:count,fps:rate);try control.check()
                guard try await verify(partial,width:job.width,height:job.height,frames:count,fps:rate) else{throw WuduhError.message("لم ينجح فحص دقة أو إطارات الجزء.")}
                if FileManager.default.fileExists(atPath:part.path){try FileManager.default.removeItem(at:part)};try FileManager.default.moveItem(at:partial,to:part)
                job.completed=segment+1;try JobStore.save(job)
            } catch {try? FileManager.default.removeItem(at:partial);job.status="متوقفة";job.detail=error.localizedDescription;try? JobStore.save(job);throw error}
        }
        try control.check();progress(job,0.98,"دمج الأجزاء وإعادة الصوت…")
        let result=try await merge(job,asset:asset,control:control)
        guard try await verify(result,width:job.width,height:job.height,frames:totalFrames,fps:rate) else{throw WuduhError.message("لم ينجح فحص الملف النهائي. الأجزاء محفوظة.")}
        job=try await finalize(job,output:result,source:asset,frames:totalFrames)
        for i in 0..<total{try? FileManager.default.removeItem(at:dir.appendingPathComponent(String(format:"part-%06d.mp4",i)))}
        progress(job,1,"اكتملت المعالجة والتحقق");return job
    }
    private func finalize(_ original:VideoJob,output:URL,source:AVAsset,frames:Int) async throws -> VideoJob {
        var job=original
        let audio = !(try await AVURLAsset(url:output).loadTracks(withMediaType:.audio)).isEmpty
        let report=ExportReport(width:job.width,height:job.height,fps:job.options.fps,frames:frames,seconds:job.duration,audio:audio,model:job.options.ai ? "Real-ESRGAN general-x4v3 / bundled ONNX":"disabled",aiStrength:job.options.aiStrength,aiLongEdge:job.options.aiLongEdge)
        try JSONEncoder().encode(report).write(to:output.appendingPathExtension("report.json"),options:.atomic)
        let expectedAudio = !(try await source.loadTracks(withMediaType:.audio)).isEmpty
        if expectedAudio && !audio {throw WuduhError.message("الصوت مفقود من النتيجة؛ بقيت الأجزاء محفوظة.")}
        job.completed=job.total;job.output=output.path;job.status="مكتملة";job.detail=nil;try JobStore.save(job)
        let folder=JobStore.folder(job.id)
        for i in 0..<job.total {for name in [String(format:"part-%06d.mp4",i),String(format:"part-%06d.working.mp4",i)]{try? FileManager.default.removeItem(at:folder.appendingPathComponent(name))}}
        try? FileManager.default.removeItem(at:folder.appendingPathComponent("final.working.mov"))
        return job
    }
    private func merge(_ job:VideoJob,asset:AVAsset,control:RunControl) async throws -> URL {
        let dir=JobStore.folder(job.id),composition=AVMutableComposition()
        guard let video=composition.addMutableTrack(withMediaType:.video,preferredTrackID:kCMPersistentTrackID_Invalid) else{throw WuduhError.message("تعذر إنشاء مسار الدمج.")}
        var cursor=CMTime.zero;var sum:Int64=0
        for i in 0..<job.total {try control.check();let part=AVURLAsset(url:dir.appendingPathComponent(String(format:"part-%06d.mp4",i)));guard let track=try await part.loadTracks(withMediaType:.video).first else{throw WuduhError.message("جزء فيديو غير موجود.")};let frames=min(2*job.options.fps,job.frameCount-Int(sum));let duration=CMTime(value:Int64(frames),timescale:Int32(job.options.fps));try video.insertTimeRange(CMTimeRange(start:.zero,duration:duration),of:track,at:cursor);cursor=cursor+duration;sum+=Int64(frames)}
        if let sourceAudio=try await asset.loadTracks(withMediaType:.audio).first,let audio=composition.addMutableTrack(withMediaType:.audio,preferredTrackID:kCMPersistentTrackID_Invalid){let available=try await sourceAudio.load(.timeRange),range=CMTimeRangeGetIntersection(available,otherRange:CMTimeRange(start:.zero,duration:cursor));if range.duration.seconds>0{try audio.insertTimeRange(range,of:sourceAudio,at:range.start)}}
        var bytes:Int64=0;for i in 0..<job.total {bytes+=Int64((try? dir.appendingPathComponent(String(format:"part-%06d.mp4",i)).resourceValues(forKeys:[.fileSizeKey]).fileSize) ?? 0)}
        guard JobStore.free()>bytes+128*1024*1024 else{throw WuduhError.message("لا تكفي مساحة الدمج؛ الأجزاء المكتملة محفوظة.")}
        let output=dir.appendingPathComponent("Wuduh-\(job.options.edge)p-\(job.options.fps)fps.mov"),temporary=dir.appendingPathComponent("final.working.mov")
        try? FileManager.default.removeItem(at:temporary)
        guard let export=AVAssetExportSession(asset:composition,presetName:AVAssetExportPresetPassthrough) else{throw WuduhError.message("تعذر دمج الفيديو والصوت.")};export.outputURL=temporary;export.outputFileType = .mov;export.timeRange=CMTimeRange(start:.zero,duration:cursor)
        export.exportAsynchronously{}
        while export.status == .waiting || export.status == .exporting {do{try control.check()}catch{export.cancelExport();throw error};try await Task.sleep(nanoseconds:100_000_000)}
        guard export.status == .completed else{throw export.error ?? WuduhError.message("فشل دمج الصوت والفيديو.")}
        if FileManager.default.fileExists(atPath:output.path){throw WuduhError.message("النتيجة موجودة بالفعل؛ افتحها من سجل المهام.")};try FileManager.default.moveItem(at:temporary,to:output);return output
    }
}

import Foundation
import CoreImage
import CoreVideo
import Metal
import simd

final class ImagePipeline {
    let context: CIContext
    let srgb = CGColorSpace(name:CGColorSpace.sRGB)!
    let bt709 = CGColorSpace(name:CGColorSpace.itur_709)!
    init(device: MTLDevice) { context = CIContext(mtlDevice:device,options:[.cacheIntermediates:false,.workingColorSpace:CGColorSpace(name:CGColorSpace.linearSRGB)!]) }
    static func adjustments(_ image: CIImage, options o: EnhanceOptions, white: [Float] = [1,1,1]) -> CIImage {
        var image = image.applyingFilter("CIColorMatrix",parameters:["inputRVector":CIVector(x:CGFloat(white[0]),y:0,z:0,w:0),"inputGVector":CIVector(x:0,y:CGFloat(white[1]),z:0,w:0),"inputBVector":CIVector(x:0,y:0,z:CGFloat(white[2]),w:0)])
        image = image.applyingFilter("CIExposureAdjust",parameters:["inputEV":o.exposure])
        image = image.applyingFilter("CIColorControls",parameters:["inputContrast":o.contrast,"inputSaturation":o.saturation])
        image = image.applyingFilter("CIHighlightShadowAdjust",parameters:["inputShadowAmount":o.shadows,"inputHighlightAmount":1-o.highlights*0.6])
        if o.warmth != 0 { image = image.applyingFilter("CITemperatureAndTint",parameters:["inputNeutral":CIVector(x:6500,y:0),"inputTargetNeutral":CIVector(x:6500+CGFloat(o.warmth)*40,y:0)]) }
        return image
    }
    func working(_ source: CVPixelBuffer, options: EnhanceOptions, white: [Float]) throws -> CVPixelBuffer {
        let w=CVPixelBufferGetWidth(source),h=CVPixelBufferGetHeight(source),out=try pixelBuffer(w,h)
        let image=Self.adjustments(CIImage(cvPixelBuffer:source,options:[.colorSpace:bt709]),options:options,white:white)
        context.render(image,to:out,bounds:CGRect(x:0,y:0,width:CGFloat(w),height:CGFloat(h)),colorSpace:srgb);return out
    }
    func scale(_ source: CVPixelBuffer, size: CGSize, color709: Bool = false) throws -> CVPixelBuffer {
        let out=try pixelBuffer(Int(size.width),Int(size.height));let image=CIImage(cvPixelBuffer:source,options:[.colorSpace:srgb])
        let resized=image.applyingFilter("CILanczosScaleTransform",parameters:["inputScale":size.height/image.extent.height,"inputAspectRatio":(size.width/image.extent.width)/(size.height/image.extent.height)])
        context.render(resized,to:out,bounds:CGRect(origin:.zero,size:size),colorSpace:color709 ? bt709:srgb)
        if color709 {CVBufferSetAttachment(out,kCVImageBufferColorPrimariesKey,kCVImageBufferColorPrimaries_ITU_R_709_2,.shouldPropagate);CVBufferSetAttachment(out,kCVImageBufferTransferFunctionKey,kCVImageBufferTransferFunction_ITU_R_709_2,.shouldPropagate);CVBufferSetAttachment(out,kCVImageBufferYCbCrMatrixKey,kCVImageBufferYCbCrMatrix_ITU_R_709_2,.shouldPropagate)}
        return out
    }
    func reference(_ source: CVPixelBuffer) throws -> CVPixelBuffer {
        let w=CVPixelBufferGetWidth(source),h=CVPixelBufferGetHeight(source),r=min(1,640/Double(max(w,h)))
        return try scale(source,size:CGSize(width:CGFloat(max(2,Int(Double(w)*r)/2*2)),height:CGFloat(max(2,Int(Double(h)*r)/2*2))))
    }
    func estimateWhite(_ source: CVPixelBuffer) throws -> [Float] {
        let image=CIImage(cvPixelBuffer:source,options:[.colorSpace:bt709]);var bytes=[UInt8](repeating:0,count:64*64*4)
        let resized=image.transformed(by:CGAffineTransform(scaleX:64/image.extent.width,y:64/image.extent.height))
        context.render(resized,toBitmap:&bytes,rowBytes:256,bounds:CGRect(x:0,y:0,width:64,height:64),format:.RGBA8,colorSpace:srgb)
        var sums=[Float](repeating:0,count:3),count=0
        for i in stride(from:0,to:bytes.count,by:4) { let c=(0..<3).map{Float(bytes[i+$0])/255};let hi=c.max()!,lo=c.min()!,y=0.2126*c[0]+0.7152*c[1]+0.0722*c[2]
            if y>0.12 && y<0.85 && hi>0 && (hi-lo)/hi<0.3 {for j in 0..<3{sums[j] += c[j]<0.04045 ? c[j]/12.92:pow((c[j]+0.055)/1.055,2.4)};count+=1}
        }
        guard count>40,let low=sums.min(),low>0 else{return [1,1,1]};let mean=sums.reduce(0,+)/3
        return sums.map { pow(min(1.18,max(0.85,mean/$0)),0.5) }
    }
}
struct MotionParams {var width:UInt32;var height:UInt32;var gridWidth:UInt32;var gridHeight:UInt32;var step:Float;var workWidth:Float;var workHeight:Float;var alpha:Float}
final class MotionPair {
    let ab:MTLBuffer,ba:MTLBuffer
    let width:Int,height:Int,gridWidth:Int,gridHeight:Int
    let sceneCut:Bool
    init(a:CVPixelBuffer,b:CVPixelBuffer,device:MTLDevice) throws {
        width=CVPixelBufferGetWidth(a);height=CVPixelBufferGetHeight(a);gridWidth=(width+11)/12+1;gridHeight=(height+11)/12+1
        guard width==CVPixelBufferGetWidth(b),height==CVPixelBufferGetHeight(b),let ab=device.makeBuffer(length:gridWidth*gridHeight*16,options:.storageModeShared),let ba=device.makeBuffer(length:gridWidth*gridHeight*16,options:.storageModeShared) else {throw WuduhError.message("تعذر تجهيز تقدير الحركة.")};self.ab=ab;self.ba=ba
        CVPixelBufferLockBaseAddress(a,.readOnly);CVPixelBufferLockBaseAddress(b,.readOnly)
        defer{CVPixelBufferUnlockBaseAddress(a,.readOnly);CVPixelBufferUnlockBaseAddress(b,.readOnly)}
        sceneCut=WDComputeFlow(CVPixelBufferGetBaseAddress(a)!.assumingMemoryBound(to:UInt8.self),CVPixelBufferGetBaseAddress(b)!.assumingMemoryBound(to:UInt8.self),Int32(width),Int32(height),Int32(CVPixelBufferGetBytesPerRow(a)),Int32(CVPixelBufferGetBytesPerRow(b)),12,24,ab.contents().assumingMemoryBound(to:Float.self),ba.contents().assumingMemoryBound(to:Float.self))>0.5
    }
}
final class MotionRenderer {
    let device:MTLDevice;private let queue:MTLCommandQueue;private let pipeline:MTLComputePipelineState;private var cache:CVMetalTextureCache!
    init() throws {
        guard let device=MTLCreateSystemDefaultDevice(),let queue=device.makeCommandQueue(),let fn=device.makeDefaultLibrary()?.makeFunction(name:"interpolate") else {throw WuduhError.message("محرك Metal غير متاح.")}
        self.device=device;self.queue=queue;pipeline=try device.makeComputePipelineState(function:fn)
        guard CVMetalTextureCacheCreate(kCFAllocatorDefault,nil,device,nil,&cache)==kCVReturnSuccess else {throw WuduhError.message("تعذر إنشاء ذاكرة Metal.")}
    }
    func render(a:CVPixelBuffer,b:CVPixelBuffer,pair:MotionPair,alpha:Float) throws -> CVPixelBuffer {
        if alpha<=0{return a};if alpha>=1{return b};if pair.sceneCut{return alpha<0.5 ? a:b}
        let w=CVPixelBufferGetWidth(a),h=CVPixelBufferGetHeight(a),out=try pixelBuffer(w,h)
        var textures=[CVMetalTexture]()
        for buffer in [a,b,out] { var texture:CVMetalTexture?;let r=CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault,cache,buffer,nil,.bgra8Unorm,w,h,0,&texture);guard r==kCVReturnSuccess,let texture else {throw WuduhError.message("تعذر تجهيز إطار Metal.")};textures.append(texture) }
        guard let command=queue.makeCommandBuffer(),let encoder=command.makeComputeCommandEncoder() else {throw WuduhError.message("تعذر تشغيل توليد الإطارات.")}
        encoder.setComputePipelineState(pipeline);for i in 0..<3 {encoder.setTexture(CVMetalTextureGetTexture(textures[i]),index:i)}
        encoder.setBuffer(pair.ab,offset:0,index:0);encoder.setBuffer(pair.ba,offset:0,index:1)
        var p=MotionParams(width:UInt32(w),height:UInt32(h),gridWidth:UInt32(pair.gridWidth),gridHeight:UInt32(pair.gridHeight),step:12,workWidth:Float(pair.width),workHeight:Float(pair.height),alpha:alpha)
        encoder.setBytes(&p,length:MemoryLayout<MotionParams>.stride,index:2)
        let tw=pipeline.threadExecutionWidth,th=max(1,pipeline.maxTotalThreadsPerThreadgroup/tw)
        encoder.dispatchThreads(MTLSize(width:CGFloat(w),height:CGFloat(h),depth:1),threadsPerThreadgroup:MTLSize(width:tw,height:th,depth:1));encoder.endEncoding();command.commit();command.waitUntilCompleted()
        if let error=command.error {throw error};CVMetalTextureCacheFlush(cache,0);return out
    }
}

import Foundation
import CoreVideo
import OnnxRuntimeBindings

final class AIEnhancer {
    private let env: ORTEnv
    private let session: ORTSession
    let backend: String
    init() throws {
        guard let model = Bundle.main.url(forResource: "realesr-general-x4v3", withExtension: "onnx") else { throw WuduhError.message("نموذج AI غير موجود داخل حزمة التطبيق.") }
        env = try ORTEnv(loggingLevel: .warning)
        let options = try ORTSessionOptions();try options.setIntraOpNumThreads(2)
        var name="ONNX Runtime / CPU"
        var loaded:ORTSession?
        if ORTIsCoreMLExecutionProviderAvailable() {
            do {
                let core=ORTCoreMLExecutionProviderOptions();core.onlyAllowStaticInputShapes=true;core.createMLProgram=true
                try options.appendCoreMLExecutionProvider(with:core)
                loaded=try ORTSession(env:env,modelPath:model.path,sessionOptions:options)
                name="ONNX Runtime / Core ML (الأجزاء غير المدعومة على CPU)"
            } catch { loaded=nil }
        }
        if loaded==nil {let cpu=try ORTSessionOptions();try cpu.setIntraOpNumThreads(2);loaded=try ORTSession(env:env,modelPath:model.path,sessionOptions:cpu)}
        session=loaded!;backend=name
    }
    func enhance(_ source: CVPixelBuffer, strength: Float, control: RunControl) throws -> CVPixelBuffer {
        let w = CVPixelBufferGetWidth(source), h = CVPixelBufferGetHeight(source), tile = 192, halo = 40, core = 112
        let result = try pixelBuffer(w*4,h*4)
        CVPixelBufferLockBaseAddress(source,.readOnly);CVPixelBufferLockBaseAddress(result,[])
        defer { CVPixelBufferUnlockBaseAddress(source,.readOnly);CVPixelBufferUnlockBaseAddress(result,[]) }
        guard let src = CVPixelBufferGetBaseAddress(source)?.assumingMemoryBound(to: UInt8.self), let dst = CVPixelBufferGetBaseAddress(result)?.assumingMemoryBound(to: UInt8.self) else { throw WuduhError.message("تعذر قراءة البكسلات.") }
        let row = CVPixelBufferGetBytesPerRow(source), destRow = CVPixelBufferGetBytesPerRow(result)
        for y in stride(from:0,to:h,by:core) { for x in stride(from:0,to:w,by:core) {
            try control.check()
            try autoreleasepool {
                let data = NSMutableData(length:3*tile*tile*MemoryLayout<Float>.stride)!
                WDFillTile(src,Int32(w),Int32(h),Int32(row),Int32(x),Int32(y),Int32(tile),Int32(halo),data.mutableBytes.assumingMemoryBound(to:Float.self))
                let input = try ORTValue(tensorData:data,elementType:.float,shape:[1,3,192,192])
                let values = try session.run(withInputs:["input":input],outputNames:["output"],runOptions:nil)
                guard let output = values["output"] else { throw WuduhError.message("لم ينتج النموذج إطارًا.") }
                let tensor = try output.tensorData()
                guard tensor.length == 3*768*768*MemoryLayout<Float>.stride else { throw WuduhError.message("أبعاد خرج النموذج غير صحيحة.") }
                WDWriteTile(tensor.bytes.assumingMemoryBound(to:Float.self),Int32(tile),Int32(halo),Int32(x),Int32(y),Int32(min(core,w-x)),Int32(min(core,h-y)),src,Int32(w),Int32(h),Int32(row),dst,Int32(destRow),strength)
            }
        } }
        return result
    }
}

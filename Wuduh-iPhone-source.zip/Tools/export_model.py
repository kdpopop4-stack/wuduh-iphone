import io,zipfile,pickle,collections,json,hashlib,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).parent/'python-deps'))
import onnx
from onnx import helper as H, numpy_helper as N, TensorProto as T
root=Path(__file__).resolve().parents[1]; source=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'realesr-general-x4v3.pth'; out=root/'Models';out.mkdir(parents=True,exist_ok=True)
z=zipfile.ZipFile(source)
class Tensor:
 def __init__(self,storage,offset,size,stride,*args): self.storage,self.offset,self.size,self.stride=storage,offset,size,stride
 def array(self):
  a=np.frombuffer(z.read('archive/data/'+self.storage[2]),dtype='<f4')
  assert len(a)==self.storage[4] and self.offset>=0
  maxindex=self.offset+sum((n-1)*s for n,s in zip(self.size,self.stride));assert maxindex<len(a)
  return np.lib.stride_tricks.as_strided(a[self.offset:],shape=self.size,strides=tuple(s*4 for s in self.stride)).copy()
class Safe(pickle.Unpickler):
 def find_class(self,m,n):
  if (m,n)==('collections','OrderedDict'):return collections.OrderedDict
  if (m,n)==('torch._utils','_rebuild_tensor_v2'):return Tensor
  if (m,n)==('torch','FloatStorage'):return 'FloatStorage'
  raise ValueError((m,n))
 def persistent_load(self,p):
  assert len(p)==5 and p[0]=='storage' and p[1]=='FloatStorage' and p[4]>0
  return p
weights=Safe(io.BytesIO(z.read('archive/data.pkl'))).load(); weights=weights.get('params_ema',weights.get('params',weights))
init=[];nodes=[];last='input'
for i in range(0,67,2):
 w=weights[f'body.{i}.weight'].array();b=weights[f'body.{i}.bias'].array();wn=f'w{i}';bn=f'b{i}';init.extend([N.from_array(w,wn),N.from_array(b,bn)]);name=f'conv{i}';nodes.append(H.make_node('Conv',[last,wn,bn],[name],pads=[1]*4,strides=[1,1]));last=name
 if i<66:
  p=weights[f'body.{i+1}.weight'].array().reshape(64,1,1);pn=f'p{i}';init.append(N.from_array(p,pn));name=f'act{i}';nodes.append(H.make_node('PRelu',[last,pn],[name]));last=name
nodes.append(H.make_node('DepthToSpace',[last],['up'],blocksize=4,mode='CRD'));init.append(N.from_array(np.array([1,1,4,4],np.float32),'scales'));nodes.append(H.make_node('Resize',['input','','scales'],['nearest'],mode='nearest',coordinate_transformation_mode='asymmetric',nearest_mode='floor'));nodes.append(H.make_node('Add',['up','nearest'],['raw']));init.extend([N.from_array(np.array(0,np.float32),'lo'),N.from_array(np.array(1,np.float32),'hi')]);nodes.append(H.make_node('Clip',['raw','lo','hi'],['output']))
def model(shape):
 g=H.make_graph(nodes,'RealESRGAN-General-x4v3',[H.make_tensor_value_info('input',T.FLOAT,[1,3,*shape])],[H.make_tensor_value_info('output',T.FLOAT,[1,3,shape[0]*4 if isinstance(shape[0],int) else 'OH',shape[1]*4 if isinstance(shape[1],int) else 'OW'])],init)
 m=H.make_model(g,opset_imports=[H.make_opsetid('',17)],producer_name='Wuduh reproducible official SRVGG conversion');m.ir_version=9;onnx.checker.check_model(m);return m
onnx.save(model([192,192]),out/'realesr-general-x4v3.onnx');onnx.save(model(['H','W']),Path(__file__).parent/'dynamic-reference.onnx')
info={'model':'Real-ESRGAN realesr-general-x4v3','source':'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesr-general-x4v3.pth','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'onnx_sha256':hashlib.sha256((out/'realesr-general-x4v3.onnx').read_bytes()).hexdigest(),'input':'input','output':'output','shape':[1,3,192,192],'output_shape':[1,3,768,768],'tile':192,'halo':40,'core':112,'RGB_range':[0,1],'license':'BSD-3-Clause','architecture':'official SRVGGNetCompact: 64 features, 32 body convolutions, PReLU, pixelshuffle4 and nearest residual','notes':'Converted directly from official tensor weights using a restricted checkpoint reader; no random weights.'}
(out/'model.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2))
